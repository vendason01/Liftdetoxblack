
import React from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import BenefitsSection from '@/components/BenefitsSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import ComparisonSection from '@/components/ComparisonSection';
import OffersSection from '@/components/OffersSection';
import GuaranteeSection from '@/components/GuaranteeSection';
import FAQSection from '@/components/FAQSection';
import Footer from '@/components/Footer';
import { Toaster } from "@/components/ui/toaster";
import { motion, AnimatePresence } from 'framer-motion';

function App() {
  return (
    <div className="flex flex-col min-h-screen bg-brand-dark-gray">
      <Header />
      <main className="flex-grow">
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <HeroSection />
            <BenefitsSection />
            <TestimonialsSection />
            <ComparisonSection />
            <OffersSection />
            <GuaranteeSection />
            <FAQSection />
          </motion.div>
        </AnimatePresence>
      </main>
      <Footer />
      <Toaster />
    </div>
  );
}

export default App;
