
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';

const CountdownTimer = () => {
  const calculateTimeLeft = () => {
    const difference = +new Date("2025-12-31T23:59:59") - +new Date(); // Example end date
    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    } else {
      timeLeft = { hours: 0, minutes: 0, seconds: 0 };
    }
    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearTimeout(timer);
  });

  const formatTime = (time) => (time < 10 ? `0${time}` : time);

  return (
    <div className="flex items-center space-x-2 digital-font text-brand-lime">
      <Clock size={28} className="mr-1" />
      <span className="text-2xl md:text-3xl">{formatTime(timeLeft.hours)}</span>
      <span className="text-2xl md:text-3xl">:</span>
      <span className="text-2xl md:text-3xl">{formatTime(timeLeft.minutes)}</span>
      <span className="text-2xl md:text-3xl">:</span>
      <span className="text-2xl md:text-3xl">{formatTime(timeLeft.seconds)}</span>
    </div>
  );
};

const Header = () => {
  return (
    <header className="bg-brand-dark-gray sticky top-0 z-50 shadow-lg">
      <motion.div 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="bg-brand-lime text-center py-2 px-4 text-brand-dark-gray font-bold text-sm md:text-base"
      >
        ATENÇÃO: Oferta válida apenas por hoje!
      </motion.div>
      <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row justify-between items-center">
        <motion.div 
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
          className="text-3xl font-extrabold text-white mb-2 md:mb-0"
        >
          Lift Detox <span className="text-brand-lime">Black</span>
        </motion.div>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
        >
          <CountdownTimer />
        </motion.div>
      </div>
    </header>
  );
};

export default Header;
