
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Leaf, ShieldCheck, Activity, Flame, HeartPulse } from 'lucide-react';

const benefits = [
  { icon: <Flame size={40} className="text-brand-lime" />, text: "Reduz gordura abdominal" },
  { icon: <Zap size={40} className="text-brand-lime" />, text: "Aumenta sua energia e disposição" },
  { icon: <Leaf size={40} className="text-brand-lime" />, text: "Desintoxica o organismo profundamente" },
  { icon: <Activity size={40} className="text-brand-lime" />, text: "Regula o intestino de forma natural" },
  { icon: <ShieldCheck size={40} className="text-brand-lime" />, text: "Composição 100% natural e segura" },
  { icon: <HeartPulse size={40} className="text-brand-lime" />, text: "Sem efeitos colaterais indesejados" },
];

const BenefitsSection = () => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.15,
        duration: 0.5,
        ease: "easeOut"
      }
    })
  };

  return (
    <section className="py-16 md:py-24 bg-brand-deep-gray text-white">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 md:mb-16"
        >
          Transforme Seu Corpo e Saúde com <span className="text-brand-lime">Lift Detox Black</span>
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.3 }}
              variants={cardVariants}
              className="bg-brand-dark-gray p-6 rounded-xl shadow-2xl border border-brand-lime/20 hover:border-brand-lime/50 transition-all duration-300 transform hover:scale-105"
            >
              <div className="flex items-center mb-4">
                <div className="bg-brand-lime/10 p-3 rounded-full mr-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-100">{benefit.text}</h3>
              </div>
              {/* Optional: Add a short description for each benefit if needed */}
              {/* <p className="text-gray-400 text-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
