
import React from 'react';
import { motion } from 'framer-motion';

const ComparisonSection = () => {
  return (
    <section className="py-16 md:py-24 bg-brand-dark-gray text-white">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-3xl md:text-4xl font-bold text-center mb-12"
        >
          Você também pode conquistar <span className="text-brand-lime">seu corpo ideal</span> com segurança!
        </motion.h2>
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative w-full max-w-4xl mx-auto aspect-[16/7] rounded-lg overflow-hidden shadow-2xl border-4 border-brand-lime/50"
        >
          <div className="absolute inset-0 flex">
            <div className="w-1/2 h-full">
              <img  class="w-full h-full object-cover object-center" alt="Imagem antes do tratamento" src="https://images.unsplash.com/photo-1587996616596-b714c1c54146" />
              <div className="absolute bottom-4 left-4 bg-red-600 text-white px-3 py-1 rounded text-sm font-semibold">ANTES: Desmotivada e com excesso de peso</div>
            </div>
            <div className="w-1/2 h-full">
              <img  class="w-full h-full object-cover object-center" alt="Imagem depois do tratamento" src="https://images.unsplash.com/photo-1650289090342-ab792ac872c4" />
              <div className="absolute bottom-4 right-4 bg-brand-lime text-brand-dark-gray px-3 py-1 rounded text-sm font-semibold">DEPOIS: Radiante, em forma e cheia de energia</div>
            </div>
          </div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-1 h-full bg-brand-lime shadow-lg"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-brand-lime p-3 rounded-full shadow-xl">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left-right text-brand-dark-gray h-6 w-6"><path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/></svg>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ComparisonSection;
