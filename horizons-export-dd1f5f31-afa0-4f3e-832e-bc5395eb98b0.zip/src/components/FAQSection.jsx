
import React from 'react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { motion } from 'framer-motion';

const faqs = [
  {
    question: "Como devo tomar o Lift Detox Black?",
    answer: "Recomenda-se tomar 2 cápsulas ao dia, uma antes do almoço e outra antes do jantar, com um copo de água. Para melhores resultados, utilize de forma contínua."
  },
  {
    question: "Em quanto tempo começo a ver os resultados?",
    answer: "Os resultados podem variar de pessoa para pessoa, mas muitos clientes relatam sentir os primeiros efeitos, como aumento de energia e melhora na digestão, já nas primeiras semanas de uso. Resultados mais significativos na perda de peso geralmente são observados após 30 dias de uso contínuo."
  },
  {
    question: "O Lift Detox Black é seguro? Possui aprovação da Anvisa?",
    answer: "Sim, Lift Detox Black é 100% seguro. Sua fórmula é composta por ingredientes naturais e é aprovada pela ANVISA (Agência Nacional de Vigilância Sanitária), seguindo todas as normas e padrões de qualidade."
  },
  {
    question: "Quem pode usar o Lift Detox Black?",
    answer: "Lift Detox Black é indicado para adultos saudáveis que buscam auxílio na perda de peso e desintoxicação do organismo. Gestantes, lactantes, crianças e pessoas com doenças preexistentes ou que utilizam medicação contínua devem consultar um médico antes de iniciar o uso."
  },
  {
    question: "O produto possui alguma contraindicação ou efeito colateral?",
    answer: "Por ser um produto com composição natural, Lift Detox Black geralmente não apresenta efeitos colaterais quando consumido conforme as instruções. No entanto, em caso de hipersensibilidade a algum componente da fórmula, o uso deve ser interrompido. Não possui contraindicações significativas para adultos saudáveis, mas a consulta médica é sempre recomendada em casos específicos."
  }
];

const FAQSection = () => {
  return (
    <section className="py-16 md:py-24 bg-brand-deep-gray text-white">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-3xl md:text-4xl font-bold text-center mb-12"
        >
          Perguntas Frequentes <span className="text-brand-lime">(FAQ)</span>
        </motion.h2>
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem value={`item-${index + 1}`} key={index}>
                <AccordionTrigger>{faq.question}</AccordionTrigger>
                <AccordionContent>
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQSection;
