
import React from 'react';
import { motion } from 'framer-motion';

const testimonials = [
  { name: "Ana Silva", age: 34, location: "São Paulo, SP", beforeImg: "Placeholder Before Ana", afterImg: "Placeholder After Ana", story: "Perdi 7kg em 4 semanas! Minha energia aumentou e me sinto muito mais confiante." },
  { name: "Carlos Pereira", age: 42, location: "Rio de Janeiro, RJ", beforeImg: "Placeholder Before Carlos", afterImg: "Placeholder After Carlos", story: "Finalmente me livrei daquela barriguinha indesejada. Lift Detox Black funciona!" },
  { name: "Juliana Santos", age: 28, location: "Belo Horizonte, MG", beforeImg: "Placeholder Before Juliana", afterImg: "Placeholder After Juliana", story: "Resultados incríveis e sem sofrimento. Recomendo para todos!" },
];

const TestimonialsSection = () => {
  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9 },
    visible: (i) => ({
      opacity: 1,
      scale: 1,
      transition: {
        delay: i * 0.2,
        duration: 0.6,
        ease: "easeOut"
      }
    })
  };

  return (
    <section className="py-16 md:py-24 bg-gray-100 text-brand-deep-gray">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-3xl md:text-4xl font-bold text-center mb-6"
        >
          Mais de <span className="text-brand-lime">7.000 pessoas</span> já transformaram seus corpos!
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          className="text-center text-lg text-gray-700 mb-12 md:mb-16"
        >
          Veja o que nossos clientes estão dizendo:
        </motion.p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              variants={cardVariants}
              className="bg-white rounded-xl shadow-2xl overflow-hidden transform transition-all duration-300 hover:shadow-brand-lime/30 hover:scale-105"
            >
              <div className="flex">
                <div className="w-1/2">
                  <img  class="w-full h-64 object-cover" alt={`Antes - ${testimonial.name}`} src="https://images.unsplash.com/photo-1677695959861-5b875fd70a21" />
                  <p className="text-center py-1 bg-red-500 text-white text-sm font-semibold">ANTES</p>
                </div>
                <div className="w-1/2">
                  <img  class="w-full h-64 object-cover" alt={`Depois - ${testimonial.name}`} src="https://images.unsplash.com/photo-1677695959861-5b875fd70a21" />
                  <p className="text-center py-1 bg-brand-lime text-brand-dark-gray text-sm font-semibold">DEPOIS</p>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-brand-deep-gray mb-1">{testimonial.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{testimonial.age} anos - {testimonial.location}</p>
                <p className="text-gray-700 leading-relaxed text-sm">"{testimonial.story}"</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
