
import React from 'react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { Star, CheckCircle, AlertTriangle } from 'lucide-react';

const offers = [
  {
    id: 1,
    name: "1 Pote",
    price: "R$137",
    tagline: "Ideal para Testar",
    buttonText: "Quero 1 Pote",
    bottlesImage: "1 Pote Lift Detox Black",
    discount: "10%",
    bestValue: false,
    altText: "Um pote de Lift Detox Black",
  },
  {
    id: 2,
    name: "Compre 2, Leve 3",
    price: "R$237",
    tagline: "Mais Vendido",
    buttonText: "Quero 3 Potes",
    bottlesImage: "3 Potes Lift Detox Black",
    discount: "30%",
    bestValue: true,
    altText: "Três potes de Lift Detox Black, sendo um grátis",
  },
  {
    id: 3,
    name: "Compre 3, Leve 5",
    price: "R$337",
    tagline: "Resultado Profundo",
    buttonText: "Quero 5 Potes",
    bottlesImage: "5 Potes Lift Detox Black",
    discount: "45%",
    bestValue: false,
    altText: "Cinco potes de Lift Detox Black, sendo dois grátis",
  },
  {
    id: 4,
    name: "Compre 5, Leve 10",
    price: "R$637",
    tagline: "Transformação Completa",
    buttonText: "Quero 10 Potes",
    bottlesImage: "10 Potes Lift Detox Black",
    discount: "60%",
    bestValue: false,
    altText: "Dez potes de Lift Detox Black, sendo cinco grátis",
  },
];

const OffersSection = () => {
  const cardVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.15,
        duration: 0.6,
        ease: "easeOut"
      }
    })
  };

  return (
    <section id="offers-section" className="py-16 md:py-24 bg-brand-deep-gray text-white">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-4xl md:text-5xl font-extrabold text-center mb-4"
        >
          Escolha seu Kit <span className="text-brand-lime">Lift Detox Black</span>
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: -10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.7, delay: 0.2, ease: "easeOut" }}
          className="text-center text-xl text-gray-300 mb-12 md:mb-16"
        >
          Ofertas Exclusivas por Tempo Limitado. Aproveite!
        </motion.p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {offers.map((offer, index) => (
            <motion.div
              key={offer.id}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.2 }}
              variants={cardVariants}
              className={`bg-brand-dark-gray p-6 rounded-xl shadow-2xl border-2 transition-all duration-300 flex flex-col justify-between
                ${offer.bestValue ? 'border-brand-lime scale-105 shadow-brand-lime/30' : 'border-gray-700 hover:border-brand-lime/70'}`}
            >
              <div>
                {offer.bestValue && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-brand-lime text-brand-dark-gray px-4 py-1 rounded-full text-sm font-bold shadow-md flex items-center">
                    <Star size={16} className="mr-1 fill-current"/> MAIS VENDIDO
                  </div>
                )}
                <img  class="w-full h-48 object-contain mb-4 mx-auto" alt={offer.altText} src="https://images.unsplash.com/photo-1513625098681-4bac5093d16a" />
                <h3 className="text-2xl font-bold text-center text-brand-lime mb-1">{offer.name}</h3>
                <p className="text-center text-gray-300 text-sm mb-3 font-semibold">{offer.tagline}</p>
                <p className="text-center text-4xl font-extrabold text-white mb-1">{offer.price}</p>
                <p className="text-center text-sm text-brand-gold mb-4 line-through">De R$ {parseFloat(offer.price.replace('R$', '')) * (100 / (100-parseFloat(offer.discount))) .toFixed(2)}</p>
                
                <div className="my-3 text-center">
                  <span className="bg-red-600 text-white text-xs font-semibold px-3 py-1 rounded-full">
                    {offer.discount} DE DESCONTO
                  </span>
                </div>
              </div>

              <div className="mt-auto">
                 <Button 
                  size="lg" 
                  className={`w-full mt-4 font-bold py-3 text-lg
                    ${offer.bestValue ? 'bg-brand-lime text-brand-dark-gray hover:bg-lime-400 shadow-lg shadow-brand-lime/30' : 'bg-gray-600 text-white hover:bg-gray-500'}`}
                 >
                  {offer.buttonText}
                </Button>
                <div className="text-xs text-gray-400 mt-3 text-center space-y-1">
                  <p className="flex items-center justify-center"><CheckCircle size={14} className="text-brand-lime mr-1" /> Garantia de 30 dias</p>
                  <p className="flex items-center justify-center"><AlertTriangle size={14} className="text-yellow-400 mr-1" /> Últimas unidades disponíveis!</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default OffersSection;
