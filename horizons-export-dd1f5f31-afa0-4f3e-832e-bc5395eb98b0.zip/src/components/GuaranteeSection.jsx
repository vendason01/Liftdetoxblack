
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck } from 'lucide-react';

const GuaranteeSection = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-r from-yellow-400 via-brand-gold to-yellow-500 text-brand-deep-gray">
      <div className="container mx-auto px-4 text-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.5 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-3xl mx-auto"
        >
          <ShieldCheck size={80} className="mx-auto mb-6 text-brand-deep-gray drop-shadow-lg" />
          <h2 className="text-3xl md:text-4xl font-extrabold mb-4">
            GARANTIA INCONDICIONAL <span className="block">30 DIAS</span>
          </h2>
          <div className="w-24 h-1.5 bg-brand-deep-gray mx-auto mb-6 rounded-full"></div>
          <p className="text-lg md:text-xl leading-relaxed mb-8">
            Sua satisfação é nossa prioridade número um. Você tem 30 dias completos para testar o Lift Detox Black. Se, por qualquer motivo, você não amar os resultados e a transformação que ele proporciona, basta entrar em contato e nós devolveremos 100% do seu dinheiro. Simples assim, sem perguntas, sem burocracia.
          </p>
          <p className="text-xl md:text-2xl font-bold">
            Seu risco é <span className="underline decoration-wavy decoration-brand-deep-gray">ZERO!</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default GuaranteeSection;
