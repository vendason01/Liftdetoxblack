
import React from 'react';
import { motion } from 'framer-motion';

const Footer = () => {
  return (
    <footer className="bg-black text-gray-300 py-12">
      <div className="container mx-auto px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center"
        >
          <div className="text-2xl font-bold text-white mb-4">
            Lift Detox <span className="text-brand-lime">Black</span>
          </div>
          <div className="flex justify-center space-x-6 mb-6">
            <a href="#privacy" className="hover:text-brand-lime transition-colors">Política de Privacidade</a>
            <a href="#terms" className="hover:text-brand-lime transition-colors">Termos de Uso</a>
            <a href="#refund" className="hover:text-brand-lime transition-colors">Política de Reembolso</a>
          </div>
          <p className="text-xs text-gray-500 max-w-2xl mx-auto mb-2">
            Este produto não se destina a diagnosticar, tratar, curar ou prevenir qualquer doença. Os resultados podem variar de pessoa para pessoa. Consulte sempre um profissional de saúde qualificado antes de iniciar qualquer programa de suplementação ou dieta.
          </p>
          <p className="text-xs text-gray-500 max-w-2xl mx-auto">
            Este site não é afiliado ao Facebook™ ou Google™ ou qualquer entidade do Facebook™ ou Google™. Depois que você sair do Facebook™ ou Google™, a responsabilidade não é deles e sim do nosso site. Fazemos todos os esforços para indicar claramente e mostrar todas as provas do produto e usamos resultados reais.
          </p>
          <p className="text-sm mt-6">
            © {new Date().getFullYear()} Lift Detox Black. Todos os direitos reservados.
          </p>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
