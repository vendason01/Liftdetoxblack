
import React from 'react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

const HeroSection = () => {
  return (
    <section className="relative py-20 md:py-32 bg-gradient-to-br from-brand-deep-gray via-brand-dark-gray to-black text-white overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        {/* Placeholder for a subtle background pattern or texture if desired */}
      </div>
      <div className="container mx-auto px-4 text-center relative z-10">
        <motion.div 
          className="absolute -top-20 -left-40 opacity-30"
          animate={{ rotate: 360 }}
          transition={{ duration: 100, repeat: Infinity, ease: "linear" }}
        >
          <img  class="w-96 h-96" alt="Abstract circular design element" src="https://images.unsplash.com/photo-1524734431057-366c5a96475c" />
        </motion.div>
        <motion.div 
          className="absolute -bottom-20 -right-40 opacity-30"
          animate={{ rotate: -360 }}
          transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
        >
          <img  class="w-80 h-80" alt="Abstract geometric design element" src="https://images.unsplash.com/photo-1649053180598-80897ee61280" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-12"
        >
          <img  class="mx-auto w-full max-w-md md:max-w-lg h-auto drop-shadow-2xl" alt="Lift Detox Black product bottles" src="https://images.unsplash.com/photo-1646996712175-6afff03f13df" />
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight"
        >
          Perca até <span className="text-brand-lime">8kg em 30 dias</span> com o poder natural do <span className="text-brand-gold">Lift Detox Black!</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="text-lg md:text-2xl text-gray-300 mb-10"
        >
          Aprovado pela Anvisa e com <span className="font-semibold text-brand-gold">garantia de 30 dias.</span>
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6, type: "spring", stiffness: 120 }}
        >
          <Button 
            size="lg" 
            className="bg-brand-lime text-brand-dark-gray hover:bg-lime-400 font-bold text-xl md:text-2xl py-4 px-10 rounded-lg shadow-lg shadow-brand-lime/40 transition-all duration-300 ease-in-out transform hover:scale-105 animate-pulse-glow"
            onClick={() => {
              const offersSection = document.getElementById('offers-section');
              if (offersSection) {
                offersSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            Quero Começar Agora!
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
